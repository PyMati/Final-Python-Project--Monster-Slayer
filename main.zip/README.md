Death - https://opengameart.org/content/no-more-magic
Theme - https://opengameart.org/content/heroic-demise-updated-version
Next day theme - https://opengameart.org/content/win-music-1
Game Music (No crede requiered) - https://pixabay.com/music/search/genre/video%20games/
Background/Foreground - https://aamatniekss.itch.io/free-pixelart-platformer-tileset/download/eyJleHBpcmVzIjoxNjczNjQ3NzI0LCJpZCI6MjQyNjU3fQ%3d%3d.WMePI0AsMHGnoXtqoPKrx7fcLVU%3d
Monsters: https://deepdivegamestudio.itch.io/humanoid-asset-pack?download
Background-Village: https://edermunizz.itch.io/free-pixel-art-forest/download/eyJpZCI6MTIxNjU4LCJleHBpcmVzIjoxNjc0NzUzMzI5fQ%3d%3d.htzy4%2bfizLeX5NfjPG3LNruEOmg%3d
NPC: https://creativekind.itch.io/npc-mage-free/download/eyJpZCI6MTEzNTQ4OSwiZXhwaXJlcyI6MTY3NDc1NDEzMH0%3d.MZiXS%2bdnRI2WqA8zWOAKrBwFeyU%3d
Effects: https://ppeldo.itch.io/2d-pixel-art-game-spellmagic-fx?download